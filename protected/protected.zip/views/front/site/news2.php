<?php
/**
 * Created by PhpStorm.
 * User: hottern
 * Date: 02.02.14
 * Time: 22:05
 */
$this->widget(
    'ext.yii-feed-widget.YiiFeedWidget',
    array('url'=>'http://techcrunch.com/rssfeeds/','limit'=>3)
);