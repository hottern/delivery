<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Strahovanie';
$this->breadcrumbs=array(
    'Strahovanie',
);
?>

</p><p style="margin-bottom: 0.35cm"><font size="3"><b>Страхование</b></font></p>
<p style="margin-bottom: 0.35cm"><font size="3"><span lang="en-US">Ma</span></font><font size="3">
    </font><font size="3"><span lang="en-US">Express</span></font><font size="3">,
        доставляя товары   обеспечивает контроль
        сохранности и безопасности почтовых
        отправлений  в течение всего пути.</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Для обеспечения
        дополнительных гарантий сохранности
        экспресс-отправлений  </font><font size="3"><span lang="en-US">Ma</span></font><font size="3">
    </font><font size="3"><span lang="en-US">Express</span></font><font size="3">
        предлагает возможность страхования
        отправлений </font><font size="3"><span lang="en-US">Ma</span></font><font size="3">
    </font><font size="3"><span lang="en-US">Express</span></font><font size="3">
        от рисков повреждения или утери.</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Доплата к
        тарифу на пересылку застрахованного
        отправления составляет 2 % от страховой
        суммы.</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Для того, чтобы
        самостоятельно высчитать  размер
        страховой премии и оплатить ее вместе
        с платой за почтовое отправлении, написав
        в уведомлении об оплате «в том  числе
        ……... руб. за страхование».</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Страхование
        применяется только для экспресс доставки.
    </font>
</p>