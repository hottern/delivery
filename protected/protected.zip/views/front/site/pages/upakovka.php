<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Strahovanie';
$this->breadcrumbs=array(
    'Strahovanie',
);
?>

<p style="margin-bottom: 0.35cm"><font size="3"><b>Дополнительная
упаковка</b></font></p>
<p style="margin-bottom: 0.35cm"><font size="3"><span lang="en-US">Ma</span></font><font size="3">
</font><font size="3"><span lang="en-US">Express</span></font><font size="3">
    аккуратно упаковывает посылки,
отправляемые в адрес своих получателей.
  </font>
</p>
<p style="margin-bottom: 0.35cm"><font size="3">Для обеспечения
дополнительных гарантий сохранности
экспресс-отправлений  </font><font size="3"><span lang="en-US">Ma</span></font><font size="3">
</font><font size="3"><span lang="en-US">Express</span></font><font size="3">
    предлагает возможность дополнительной
упаковки.  Дополнительная  упаковка
предоставляется в виде мешка, пузырчатой
пленки и пломбы.</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Стоимость
мешка – 150 руб.

Стоимость пломбы – 50  руб.

Стоимость
пузырчатой пленки – 50 руб./п.м</font></p>
<p style="margin-bottom: 0.35cm"><font size="3">Оплата
производится   как вместе с оплатой за
почтовое отправление.  В уведомлении
об оплате необходимо написать «в том
числе  за дополнительную упаковку» и
указать вид упаковки. </font>
</p>