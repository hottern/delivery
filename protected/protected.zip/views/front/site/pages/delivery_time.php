<?php
/**
 * Created by PhpStorm.
 * User: hottern
 * Date: 15.01.14
 * Time: 10:08
 */ ?>
<style type="text/css">
    P { margin-bottom: 0.21cm; direction: ltr; color: rgb(0, 0, 0); widows: 2; orphans: 2; }A:link { color: rgb(0, 0, 255); }</style>
<p style="margin-bottom: 0.35cm">
    <font size="3"><b>Сроки доставки почтовых отправлений </b></font></p>
<p style="margin-bottom: 0.35cm">
    <br />
    &nbsp;</p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Стоимость услуг </font><font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> зависит от сроков доставки почтовых отправлений, а также от габаритов вложений. </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Ниже указаны сроки с даты отправки почтового отправления в Китае в адрес нашего центрального логистического центра до получателя в России.</font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка из Китая в Россию почтовых отправлений - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка из интернет магазинов Китая - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка образцов товара - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка мелкооптовых партий товаров - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Почтовая доставка из Китая в Россию - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка документов и посылок из России в Китай - </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Все сроки доставки отправлений </font><font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> рассчитываются в зависимости способов доставки, а также населенного пункта получателя, наличия офисов служб экспресс доставки, почтовых отделений, складов федеральных транспортных компаний.</font></p>

