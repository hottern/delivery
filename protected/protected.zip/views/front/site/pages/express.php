<?php
/**
 * Created by PhpStorm.
 * User: hottern
 * Date: 15.01.14
 * Time: 10:10
 */ ?>

<style type="text/css">
    P { margin-bottom: 0.21cm; direction: ltr; color: rgb(0, 0, 0); widows: 2; orphans: 2; }A:link { color: rgb(0, 0, 255); }</style>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс-доставка</font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> оказывает полный спектр услуг по экспресс-доставке деловой корреспонденции и грузов. Благодаря широкой географии обслуживания, оптимальному соотношению цены и качества, скорости доставки, надежности перевозок мы обеспечиваем нашим клиентам максимальное удобство в осуществлении отправки грузов из Китая в Россию. </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> сотрудничает с </font><font size="3"><span lang="en-US">SF</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> в Китае, а также с Почтой России, </font><font size="3"><span lang="en-US">EMS</span></font><font size="3"> Почта России, Желдоральянс, Желдорэкспедиция, Ратек, Пэк, Деловые линии, благодаря чему доставка отправлений может быть осуществлена из любого города Китая в любой населенный пункт России. Пересылка экспресс-отправлений осуществляется через центральный логистический центр, расположенный в г. Суйфэньхэ провинции Хэйлунцзян и логистический центр, расположенный во Владивостоке. Отправления принимаются на адрес логистического центра, проходят таможенное оформление и отправляются в адрес получателя в России.</font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Для отправки экспресс отправления отнести свое отправление в пункт приема логистического центра либо отправить экспресс отправление в адрес логистического центра </font><font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> . </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3"><b>Мы предлагаем следующие виды экспресс доставки:</b></font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка из Китая в Россию почтовых отправлений </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка из интернет магазинов Китая</font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка образцов товара </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка мелкооптовых партий товаров </font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Почтовая доставка из Китая в Россию</font></p>
<p style="margin-bottom: 0.35cm">
    <font size="3">Экспресс доставка документов и посылок из России в Китай</font></p>
<p style="margin-bottom: 0.35cm">
    <br />
    &nbsp;</p>
<p style="margin-bottom: 0.35cm">
    <br />
    &nbsp;</p>