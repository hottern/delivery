<?php
/**
 * Created by PhpStorm.
 * User: hottern
 * Date: 15.01.14
 * Time: 9:18
 */ ?>
<p>
	<style type="text/css">
    P { margin-bottom: 0.21cm; direction: ltr; color: rgb(0, 0, 0); widows: 2; orphans: 2; }A:link { color: rgb(0, 0, 255); }	</style>
</p>
<p style="margin-bottom: 0.35cm">
	<font size="3"><b>Заключить договор</b></font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Уважаемые клиенты! Заполните заявку и наши менеджеры свяжутся с вами в ближайшее время.</font></p>
<form action="feedback.php" id="feedback" method="post" name="feedback">
	<p>
        <label for="name">Имя компании</label> </br>
        <input maxlength="125" name="name" size="35" type="text" /></p>
	<p>
        <label for="adress">Адресс</label> </br>
		<input maxlength="125" name="adress" size="35" type="text" /></p>
    <p>
        <label for="phone">Телефон</label> </br>
        <input maxlength="125" name="phone" size="35" type="text" /></p>
    <p>
        <label for="email">Email</label> </br>
        <input maxlength="125" name="email" size="35" type="text" /></p>
    <p>
        <label for="skype">Skype</label> </br>
        <input maxlength="125" name="skype" size="35" type="text" /></p>
    <p>
        <label for="contact_name">Контактное лицо</label> </br>
        <input maxlength="125" name="contact_name" size="35" type="text" /></p>
    <input type="submit" value="Submit" name="yt1">
</form>

<p style="margin-top: 0.35cm">
	<font size="3">Лица, заключившие договор, получают статус корпоративного клиента. Преимуществом заключения договора является то, что нет необходимости заниматься оплатой и оформлением документов для каждого отправления. Оплата производится авансовым платежом за период времени. Договор может быть заключен как с компанией, так и с частным лицом. </font></p>
<p style="margin-bottom: 0.35cm">
	<br />
	&nbsp;</p>