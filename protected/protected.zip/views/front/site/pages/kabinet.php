<?php
/**
 * Created by PhpStorm.
 * User: hottern
 * Date: 15.01.14
 * Time: 9:43
 */
?>

<style type="text/css">
    P { margin-bottom: 0.21cm; direction: ltr; color: rgb(0, 0, 0); widows: 2; orphans: 2; }A:link { color: rgb(0, 0, 255); }</style>
<p style="margin-bottom: 0.35cm">
	<font size="3"><b>Личный кабинет</b></font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Для корпоративных клиентов </font><font size="3"><span lang="en-US">Ma</span></font><font size="3"> </font><font size="3"><span lang="en-US">Express</span></font><font size="3"> предлагает воспользоваться Личным кабинетом, что сделает процесс оформления отправлений и оплату отправлений более простым</font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Функции Личного кабинета предоставляют возможность оптимизировать процесс систематизации данных об отправках и их хранение. Информация об отправлениях сохраняется в течение трех месяцев. </font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Мы предлагаем вам для простой, быстрой и удобной работы в Личном кабинете следующие сервисы:</font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Создание отправлений</font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Просмотр отправлений </font></p>
<p style="margin-bottom: 0.35cm">
	<font size="3">Информация об оплате за отправления и за каждое отправление</font></p>
