

<div id="sidebar" class="menu2">
    <div id="yw2" class="portlet">
        <div class="portlet-decoration">
            <div class="portlet-title"><h5>Данные</h5></div>
            </div>
        <div class="portlet-content">
            <ul id="yw3" class="operations">
<?php foreach ($rows as $row) { ?>
<li><?php echo ($row); ?></li>
    <?php } ?>
            </ul>
        </div>
    </div>
</div>